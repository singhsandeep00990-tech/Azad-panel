import 'package:flutter/material.dart';

void main() {
  runApp(const SmartPanelApp());
}

class SmartPanelApp extends StatelessWidget {
  const SmartPanelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Smart Panel',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final userController = TextEditingController();
  final passwordController = TextEditingController();

  void login() {
    // Demo login. Firebase authentication will be added next.
    if (userController.text.trim().isNotEmpty &&
        passwordController.text.isNotEmpty) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const DashboardPage()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('User ID aur Password daaliye')),
      );
    }
  }

  @override
  void dispose() {
    userController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                children: [
                  const Icon(Icons.electrical_services, size: 72),
                  const SizedBox(height: 16),
                  const Text(
                    'SMART PANEL',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text('Customer Login'),
                  const SizedBox(height: 32),
                  TextField(
                    controller: userController,
                    decoration: const InputDecoration(
                      labelText: 'User ID',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.lock),
                    ),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton(
                      onPressed: login,
                      child: const Text('LOGIN'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Demo: koi bhi non-empty ID/Password se login hoga.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final List<bool> relayStates = List<bool>.filled(8, false);
  final List<bool> feedbackStates = List<bool>.filled(8, false);
  final List<double> currents = List<double>.filled(8, 0.0);

  void toggleRelay(int index, bool value) {
    setState(() {
      relayStates[index] = value;

      // Demo feedback simulation.
      // Later Firebase/ESP32 ka real feedback yahan aayega.
      feedbackStates[index] = value;
      currents[index] = value ? 2.4 : 0.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SMART PANEL'),
        actions: [
          IconButton(
            tooltip: 'Logout',
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
              );
            },
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.router),
              title: const Text(
                'PANEL-001',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: const Text('Demo mode • Cloud not connected'),
              trailing: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.orange.withOpacity(.15),
                ),
                child: const Text('DEMO'),
              ),
            ),
          ),
          const SizedBox(height: 8),
          for (int i = 0; i < 8; i++)
            RelayCard(
              number: i + 1,
              relayOn: relayStates[i],
              feedbackRunning: feedbackStates[i],
              current: currents[i],
              onChanged: (value) => toggleRelay(i, value),
            ),
        ],
      ),
    );
  }
}

class RelayCard extends StatelessWidget {
  final int number;
  final bool relayOn;
  final bool feedbackRunning;
  final double current;
  final ValueChanged<bool> onChanged;

  const RelayCard({
    super.key,
    required this.number,
    required this.relayOn,
    required this.feedbackRunning,
    required this.current,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  child: Text('$number'),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Relay $number',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Switch(
                  value: relayOn,
                  onChanged: onChanged,
                ),
              ],
            ),
            const Divider(),
            Row(
              children: [
                Expanded(
                  child: StatusTile(
                    title: 'Feedback',
                    value: feedbackRunning ? 'RUNNING' : 'STOP',
                    active: feedbackRunning,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: StatusTile(
                    title: 'Current',
                    value: '${current.toStringAsFixed(1)} A',
                    active: current > 0,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class StatusTile extends StatelessWidget {
  final String title;
  final String value;
  final bool active;

  const StatusTile({
    super.key,
    required this.title,
    required this.value,
    required this.active,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: active
            ? Colors.green.withOpacity(.10)
            : Colors.grey.withOpacity(.10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 4),
          Row(
            children: [
              Icon(
                active ? Icons.circle : Icons.circle_outlined,
                size: 12,
                color: active ? Colors.green : Colors.grey,
              ),
              const SizedBox(width: 6),
              Text(
                value,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
